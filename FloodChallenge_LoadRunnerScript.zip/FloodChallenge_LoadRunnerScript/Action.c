Action()
{
	int i;
  	int ncount;
  	char * OrderVal;
  	int tmpOrderValue;
  	int maxOrderValue = 0;
  	int indexMaxValue = 0;
  
	lr_start_transaction("00_Homepage");
		
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("_ga=GA1.1.2101383487.1646967739; DOMAIN=challenge.flood.io");

	web_add_cookie("_gcl_au=1.1.1638743757.1646967739; DOMAIN=challenge.flood.io");

	web_add_cookie("ajs_anonymous_id=d72414d7-4a3e-488a-9c86-f4a31c3004d9; DOMAIN=challenge.flood.io");

	web_add_cookie("intercom-id-jmz45abb=ef462008-d601-488a-a981-bea88a4d2d6a; DOMAIN=challenge.flood.io");

	web_add_cookie("intercom-session-jmz45abb=; DOMAIN=challenge.flood.io");

	web_add_cookie("amplitude_id_7d86229f240ee64c44d6b7aa4071377bflood.io=eyJkZXZpY2VJZCI6ImVkNWFiZmVkLTU1MjEtNDhhMS1iMjRmLWE3MDYzZTllNjk1Y1IiLCJ1c2VySWQiOm51bGwsIm9wdE91dCI6ZmFsc2UsInNlc3Npb25JZCI6MTY0NzIxNzM5NTUxMiwibGFzdEV2ZW50VGltZSI6MTY0NzIxNzM5NTUxNSwiZXZlbnRJZCI6MiwiaWRlbnRpZnlJZCI6Miwic2VxdWVuY2VOdW1iZXIiOjR9; DOMAIN=challenge.flood.io");

	web_add_cookie("_ga_218V1RJY1G=GS1.1.1647221196.3.0.1647221196.0; DOMAIN=challenge.flood.io");

	web_add_cookie("s_vi=[CS]v1|310E002B0DB25EBB-600008E98B4D2671[CE]; DOMAIN=sstats.adobe.com");

	web_add_cookie("feds_visitor_id=XNepJnZgw_S3hleXtdmjx; DOMAIN=sstats.adobe.com");

	web_add_cookie("feds_visitor_audience=%7B%22visitor%22%3A%22XNepJnZgw_S3hleXtdmjx%22%2C%22cohort%22%3Atrue%7D; DOMAIN=sstats.adobe.com");

	web_add_cookie("OptanonConsent=groups=C0001:1,C0002:1,C0003:1,C0004:1; DOMAIN=sstats.adobe.com");

	web_add_cookie("OptanonAlertBoxClosed=2023-02-27T22:51:08.060Z; DOMAIN=sstats.adobe.com");

	web_add_cookie("OptanonChoice=1; DOMAIN=sstats.adobe.com");

	web_add_cookie("_scid=4b391c62-a9cd-4dd5-a6d5-b0a80a3514ff; DOMAIN=sstats.adobe.com");

	web_add_cookie("_gcl_au=1.1.2044060428.1646002268; DOMAIN=sstats.adobe.com");

	web_add_cookie("_fbp=fb.1.1646002268617.955170621; DOMAIN=sstats.adobe.com");

	web_add_cookie("_clck=1alpzv4|1|ezc|0; DOMAIN=sstats.adobe.com");

	web_add_cookie("_sctr=1|1645966800000; DOMAIN=sstats.adobe.com");

	web_add_cookie("s_nr=1646002363236-New; DOMAIN=sstats.adobe.com");

	web_add_cookie("adcloud={%22_les_v%22:%22y%2Cadobe.com%2C1646004163%22}; DOMAIN=sstats.adobe.com");

	web_add_cookie("_uetvid=c08cf630981f11eca449a12ccad75614; DOMAIN=sstats.adobe.com");

	web_add_cookie("mbox=session#1c47121d6c034670854cd09e1ba82207#1646004224|PC#1c47121d6c034670854cd09e1ba82207.36_0#1709247164; DOMAIN=sstats.adobe.com");

	web_add_cookie("fg=WIWJHBVIFLE5ALECEAQFRHQACA======; DOMAIN=sstats.adobe.com");

	web_add_cookie("AMCV_9E1005A551ED61CA0A490D45%40AdobeOrg=-2121179033%7CMCAID%7C310E002B0DB25EBB-600008E98B4D2671%7CMCMID%7C83881056076316174522408391983676546713%7CMCAAMLH-1647898759%7C8%7CMCAAMB-1647898759%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1647301159s%7CNONE%7CMCCIDH%7C-620376024%7CMCSYNCSOP%7C411-19058%7CvVersion%7C5.3.0%7CMCIDTS%7C19051; DOMAIN=sstats.adobe.com");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");
	
	web_add_auto_header("User-Agent", 
		"I AM ROBOT");
		
/*Correlation comment - Do not change!  Original value='UiIpJXtNvKpsEpPGwu1Ihduoa2y2mGGMqm0qtuMvr5c=' Name ='authenticity_token' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=authenticity_token",
		"TagName=input",
		"Extract=value",
		"Name=authenticity_token",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='N1V6OWh3Q2M1OWFKNFBVbWtKa0JaZz09LS1FWlRUNU5mNUdCRWhQK1dmZG1PZXpRPT0=--a5c27f0b39465df471b9ad66fe92a867837dcebb' Name ='CorrelationParameter' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=CorrelationParameter",
		"TagName=input",
		"Extract=value",
		"Name=challenger[step_id]",
		"Id=challenger_step_id",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		LAST);

	web_url("challenge.flood.io", 
		"URL=https://{host_challenge_flood_io}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://{host_sstats_adobe_com}/b/ss/adbcreatepdfplugin.prod/1/JS-1.6/s72404434351353?AQB=1&ndh=1&pf=1&t=15%2F2%2F2022%209%3A50%3A55%202%20-660&fid=1669212DA82FFA6E-30A15753EFF66043&ce=UTF-8&pageName=DCBrowserExt%3AShim%3AVersion%3AUnknown%3AOp&g=chrome-extension%3A%2F%2Fefaidnbmnnnibpcajpcglclefindmkaj%2F_generated_background_page.html&v1=15.1.3.9&v2=sideload&v3=prod&v4=not_set&s=1280x720&c=24&j=1.6&v=N&k=Y&bh=8&AQE=1", "Referer=", ENDITEM, 
		"Url=https://{host_sstats_adobe_com}/b/ss/adbcreatepdfplugin.prod/1/JS-1.6/s76447395596061?AQB=1&ndh=1&pf=1&t=15%2F2%2F2022%209%3A50%3A55%202%20-660&fid=1669212DA82FFA6E-30A15753EFF66043&ce=UTF-8&pageName=DCBrowserExt%3AExtension%3AStartup%3AOp&g=chrome-extension%3A%2F%2Fefaidnbmnnnibpcajpcglclefindmkaj%2F_generated_background_page.html&v1=15.1.3.9&v2=sideload&v3=prod&v4=unknown&AQE=1", "Referer=", ENDITEM, 
		"Url=https://{host_sstats_adobe_com}/b/ss/adbcreatepdfplugin.prod/1/JS-1.6/s72327331730886?AQB=1&ndh=1&pf=1&t=15%2F2%2F2022%209%3A50%3A55%202%20-660&fid=1669212DA82FFA6E-30A15753EFF66043&ce=UTF-8&pageName=DCBrowserExt%3AOS%3Awin%3AOp&g=chrome-extension%3A%2F%2Fefaidnbmnnnibpcajpcglclefindmkaj%2F_generated_background_page.html&v1=15.1.3.9&v2=sideload&v3=prod&v4=unknown&AQE=1", "Referer=", ENDITEM, 
		LAST);

	
		
	lr_end_transaction("00_Homepage",LR_AUTO);

	lr_start_transaction("01_ClickStart");


	web_add_auto_header("Origin", 
		"https://{host_challenge_flood_io}");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

/*Correlation comment - Do not change!  Original value='QVZjbWxVbkwzY0dnY1prOHVTdXN4UT09LS0vYjJkQ0ZRaVFBMnp1Ui9qYy9mb0NnPT0=--920bc0cd3ee357709e23af3945bed7c105d5e815' Name ='CorrelationParameter_1' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=CorrelationParameter_1",
		"TagName=input",
		"Extract=value",
		"Name=challenger[step_id]",
		"Id=challenger_step_id",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=Yes",
		"RequestUrl=*/2*",
		LAST);

	web_submit_data("start",
		"Action=https://{host_challenge_flood_io}/start",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://{host_challenge_flood_io}/",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=utf8", "Value=✓", ENDITEM,
		"Name=authenticity_token", "Value={authenticity_token}", ENDITEM,
		"Name=challenger[step_id]", "Value={CorrelationParameter}", ENDITEM,
		"Name=challenger[step_number]", "Value=1", ENDITEM,
		"Name=commit", "Value=Start", ENDITEM,
		LAST);

	lr_end_transaction("01_ClickStart",LR_AUTO);
	
	//Select random age from 18 - 100;
	lr_save_int(rand() % 83 + 18, "RANDOM_AGE");

	lr_start_transaction("02_SelectAge");

/*Correlation comment - Do not change!  Original value='ZSs3R3plVWZyVXY0TGUrUVY1a29tQT09LS1GL3ExUWswWE9FTkhpOGRlMURxZS9nPT0=--c70f1b98d1f2f498aeb81a538bf17f930b07942f' Name ='CorrelationParameter_2' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=CorrelationParameter_2",
		"TagName=input",
		"Extract=value",
		"Name=challenger[step_id]",
		"Id=challenger_step_id",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=Yes",
		"RequestUrl=*/3*",
		LAST);

	web_reg_save_param_ex(
		"ParamName=OrderId",
		"LB=name=\"challenger[order_selected]\" type=\"radio\" value=\"",
		"RB=\" /><label",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=OrderValue",
		"RegExp=for=\"challenger_order_selected_.*\">(.*?)</label>",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	web_submit_data("start_2",
		"Action=https://{host_challenge_flood_io}/start",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://{host_challenge_flood_io}/step/2",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=utf8", "Value=✓", ENDITEM,
		"Name=authenticity_token", "Value={authenticity_token}", ENDITEM,
		"Name=challenger[step_id]", "Value={CorrelationParameter_1}", ENDITEM,
		"Name=challenger[step_number]", "Value=2", ENDITEM,
		"Name=challenger[age]", "Value={RANDOM_AGE}", ENDITEM,
		"Name=commit", "Value=Next", ENDITEM,
		LAST);

	ncount = lr_paramarr_len("OrderValue");
	//lr_output_message("Value of ncount is %d",ncount);
	
	for (i =1;i <= ncount;i++)
	{		
		OrderVal = lr_paramarr_idx("OrderValue", i);	
		//lr_output_message("Value of [%d] order is %s", i, OrderVal);
		tmpOrderValue = atoi(OrderVal);
		
		if (maxOrderValue < tmpOrderValue) {
      		maxOrderValue = tmpOrderValue;
      		//lr_output_message("max order value is %d", maxOrderValue);
      		indexMaxValue = i;
      		//lr_output_message("index of max order value is %d", indexMaxValue);
    	}		
		lr_save_int(maxOrderValue, "MaxOrderValue");
		lr_save_int(indexMaxValue, "IndexMaxValue");		
	}
	
	lr_save_string(lr_paramarr_idx("OrderId", indexMaxValue), "ORDER_ID");

	lr_end_transaction("02_SelectAge",LR_AUTO);

	lr_start_transaction("03_SelectOrder");

/*Correlation comment - Do not change!  Original value='T3B6VmtnS1Vid1NrRlo0ODdsSGZBQT09LS1Vbkp1VmYvZHhOK0M5NWZlOUNwNjhBPT0=--ea813e3df5b55b95b2281c865f731b15f62a3da2' Name ='CorrelationParameter_3' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=CorrelationParameter_3",
		"TagName=input",
		"Extract=value",
		"Name=challenger[step_id]",
		"Id=challenger_step_id",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=Yes",
		"RequestUrl=*/4*",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=OrderNumber",
		"RegExp=input id=\"challenger_order_.*\" name=\"challenger(.*?)\"",
		"NotFound=error",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=ORDER_VALUE",
		"RegExp=input id=\"challenger_order.*\" name=\"challenger.*\" type=\"hidden\" value=\"(.*?)\"",
		"NotFound=error",
		"Ordinal=ALL",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	web_submit_data("start_3",
		"Action=https://{host_challenge_flood_io}/start",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://{host_challenge_flood_io}/step/3",
		"Snapshot=t9.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=utf8", "Value=✓", ENDITEM,
		"Name=authenticity_token", "Value={authenticity_token}", ENDITEM,
		"Name=challenger[step_id]", "Value={CorrelationParameter_2}", ENDITEM,
		"Name=challenger[step_number]", "Value=3", ENDITEM,
		"Name=challenger[largest_order]", "Value={MaxOrderValue}", ENDITEM,
		"Name=challenger[order_selected]", "Value={ORDER_ID}", ENDITEM,
		"Name=commit", "Value=Next", ENDITEM,
		LAST);

	lr_end_transaction("03_SelectOrder",LR_AUTO);

	lr_start_transaction("04_ClickNext");

/*Correlation comment - Do not change!  Original value='S2RzcTEwdlN1RW1ZNzlUemd0dFZtZz09LS1xVFAyLzVjT1QyVzRpTzNjRUFNZjBRPT0=--73bc7709267f614143cb14f6d990de54497ba919' Name ='CorrelationParameter_4' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=CorrelationParameter_4",
		"TagName=input",
		"Extract=value",
		"Name=challenger[step_id]",
		"Id=challenger_step_id",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=Yes",
		"RequestUrl=*/5*",
		LAST);

	web_submit_data("start_4",
		"Action=https://{host_challenge_flood_io}/start",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://{host_challenge_flood_io}/step/4",
		"Snapshot=t10.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=utf8", "Value=✓", ENDITEM,
		"Name=authenticity_token", "Value={authenticity_token}", ENDITEM,
		"Name=challenger[step_id]", "Value={CorrelationParameter_3}", ENDITEM,
		"Name=challenger[step_number]", "Value=4", ENDITEM,
		"Name=challenger{OrderNumber_1}", "Value={ORDER_VALUE_1}", ENDITEM,
		"Name=challenger{OrderNumber_2}", "Value={ORDER_VALUE_2}", ENDITEM,
		"Name=challenger{OrderNumber_3}", "Value={ORDER_VALUE_3}", ENDITEM,
		"Name=challenger{OrderNumber_4}", "Value={ORDER_VALUE_4}", ENDITEM,
		"Name=challenger{OrderNumber_5}", "Value={ORDER_VALUE_5}", ENDITEM,
		"Name=challenger{OrderNumber_6}", "Value={ORDER_VALUE_6}", ENDITEM,
		"Name=challenger{OrderNumber_7}", "Value={ORDER_VALUE_7}", ENDITEM,
		"Name=challenger{OrderNumber_8}", "Value={ORDER_VALUE_8}", ENDITEM,
		"Name=challenger{OrderNumber_9}", "Value={ORDER_VALUE_9}", ENDITEM,
		"Name=challenger{OrderNumber_10}", "Value={ORDER_VALUE_10}", ENDITEM,
		"Name=commit", "Value=Next", ENDITEM,
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

/*Correlation comment - Do not change!  Original value='2802469144' Name ='code' Type ='ResponseBased'*/
	web_reg_save_param_json(
		"ParamName=code",
		"QueryString=$.code",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("code", 
		"URL=https://{host_challenge_flood_io}/code", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{host_challenge_flood_io}/step/5", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("04_ClickNext",LR_AUTO);

	lr_start_transaction("05_EnterToken");

	web_add_header("Origin", 
		"https://{host_challenge_flood_io}");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_reg_find("Fail=NotFound",
		"Text=Congratulations",
		LAST);

	web_submit_data("start_5",
		"Action=https://{host_challenge_flood_io}/start",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=https://{host_challenge_flood_io}/step/5",
		"Snapshot=t12.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=utf8", "Value=✓", ENDITEM,
		"Name=authenticity_token", "Value={authenticity_token}", ENDITEM,
		"Name=challenger[step_id]", "Value={CorrelationParameter_4}", ENDITEM,
		"Name=challenger[step_number]", "Value=5", ENDITEM,
		"Name=challenger[one_time_token]", "Value={code}", ENDITEM,
		"Name=commit", "Value=Next", ENDITEM,
		LAST);

	lr_end_transaction("05_EnterToken",LR_AUTO);

	return 0;
}