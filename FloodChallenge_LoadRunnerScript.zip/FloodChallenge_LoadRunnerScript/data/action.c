Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_url("seed", 
		"URL=https://{host_clientservices_googleapis_com}/chrome-variations/seed?osname=win&channel=stable&milestone=99", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("_ga=GA1.1.2101383487.1646967739; DOMAIN=challenge.flood.io");

	web_add_cookie("_gcl_au=1.1.1638743757.1646967739; DOMAIN=challenge.flood.io");

	web_add_cookie("ajs_anonymous_id=d72414d7-4a3e-488a-9c86-f4a31c3004d9; DOMAIN=challenge.flood.io");

	web_add_cookie("intercom-id-jmz45abb=ef462008-d601-488a-a981-bea88a4d2d6a; DOMAIN=challenge.flood.io");

	web_add_cookie("intercom-session-jmz45abb=; DOMAIN=challenge.flood.io");

	web_add_cookie("amplitude_id_7d86229f240ee64c44d6b7aa4071377bflood.io=eyJkZXZpY2VJZCI6ImVkNWFiZmVkLTU1MjEtNDhhMS1iMjRmLWE3MDYzZTllNjk1Y1IiLCJ1c2VySWQiOm51bGwsIm9wdE91dCI6ZmFsc2UsInNlc3Npb25JZCI6MTY0NzIxNzM5NTUxMiwibGFzdEV2ZW50VGltZSI6MTY0NzIxNzM5NTUxNSwiZXZlbnRJZCI6MiwiaWRlbnRpZnlJZCI6Miwic2VxdWVuY2VOdW1iZXIiOjR9; DOMAIN=challenge.flood.io");

	web_add_cookie("_ga_218V1RJY1G=GS1.1.1647221196.3.0.1647221196.0; DOMAIN=challenge.flood.io");

	web_add_cookie("s_vi=[CS]v1|310E002B0DB25EBB-600008E98B4D2671[CE]; DOMAIN=sstats.adobe.com");

	web_add_cookie("feds_visitor_id=XNepJnZgw_S3hleXtdmjx; DOMAIN=sstats.adobe.com");

	web_add_cookie("feds_visitor_audience=%7B%22visitor%22%3A%22XNepJnZgw_S3hleXtdmjx%22%2C%22cohort%22%3Atrue%7D; DOMAIN=sstats.adobe.com");

	web_add_cookie("OptanonConsent=groups=C0001:1,C0002:1,C0003:1,C0004:1; DOMAIN=sstats.adobe.com");

	web_add_cookie("OptanonAlertBoxClosed=2023-02-27T22:51:08.060Z; DOMAIN=sstats.adobe.com");

	web_add_cookie("OptanonChoice=1; DOMAIN=sstats.adobe.com");

	web_add_cookie("_scid=4b391c62-a9cd-4dd5-a6d5-b0a80a3514ff; DOMAIN=sstats.adobe.com");

	web_add_cookie("_gcl_au=1.1.2044060428.1646002268; DOMAIN=sstats.adobe.com");

	web_add_cookie("_fbp=fb.1.1646002268617.955170621; DOMAIN=sstats.adobe.com");

	web_add_cookie("_clck=1alpzv4|1|ezc|0; DOMAIN=sstats.adobe.com");

	web_add_cookie("_sctr=1|1645966800000; DOMAIN=sstats.adobe.com");

	web_add_cookie("s_nr=1646002363236-New; DOMAIN=sstats.adobe.com");

	web_add_cookie("adcloud={%22_les_v%22:%22y%2Cadobe.com%2C1646004163%22}; DOMAIN=sstats.adobe.com");

	web_add_cookie("_uetvid=c08cf630981f11eca449a12ccad75614; DOMAIN=sstats.adobe.com");

	web_add_cookie("mbox=session#1c47121d6c034670854cd09e1ba82207#1646004224|PC#1c47121d6c034670854cd09e1ba82207.36_0#1709247164; DOMAIN=sstats.adobe.com");

	web_add_cookie("fg=WIWJHBVIFLE5ALECEAQFRHQACA======; DOMAIN=sstats.adobe.com");

	web_add_cookie("AMCV_9E1005A551ED61CA0A490D45%40AdobeOrg=-2121179033%7CMCAID%7C310E002B0DB25EBB-600008E98B4D2671%7CMCMID%7C83881056076316174522408391983676546713%7CMCAAMLH-1647898759%7C8%7CMCAAMB-1647898759%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1647301159s%7CNONE%7CMCCIDH%7C-620376024%7CMCSYNCSOP%7C411-19058%7CvVersion%7C5.3.0%7CMCIDTS%7C19051; DOMAIN=sstats.adobe.com");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("challenge.flood.io", 
		"URL=https://{host_challenge_flood_io}/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://{host_sstats_adobe_com}/b/ss/adbcreatepdfplugin.prod/1/JS-1.6/s72404434351353?AQB=1&ndh=1&pf=1&t=15%2F2%2F2022%209%3A50%3A55%202%20-660&fid=1669212DA82FFA6E-30A15753EFF66043&ce=UTF-8&pageName=DCBrowserExt%3AShim%3AVersion%3AUnknown%3AOp&g=chrome-extension%3A%2F%2Fefaidnbmnnnibpcajpcglclefindmkaj%2F_generated_background_page.html&v1=15.1.3.9&v2=sideload&v3=prod&v4=not_set&s=1280x720&c=24&j=1.6&v=N&k=Y&bh=8&AQE=1", "Referer=", ENDITEM, 
		"Url=https://{host_sstats_adobe_com}/b/ss/adbcreatepdfplugin.prod/1/JS-1.6/s76447395596061?AQB=1&ndh=1&pf=1&t=15%2F2%2F2022%209%3A50%3A55%202%20-660&fid=1669212DA82FFA6E-30A15753EFF66043&ce=UTF-8&pageName=DCBrowserExt%3AExtension%3AStartup%3AOp&g=chrome-extension%3A%2F%2Fefaidnbmnnnibpcajpcglclefindmkaj%2F_generated_background_page.html&v1=15.1.3.9&v2=sideload&v3=prod&v4=unknown&AQE=1", "Referer=", ENDITEM, 
		"Url=https://{host_sstats_adobe_com}/b/ss/adbcreatepdfplugin.prod/1/JS-1.6/s72327331730886?AQB=1&ndh=1&pf=1&t=15%2F2%2F2022%209%3A50%3A55%202%20-660&fid=1669212DA82FFA6E-30A15753EFF66043&ce=UTF-8&pageName=DCBrowserExt%3AOS%3Awin%3AOp&g=chrome-extension%3A%2F%2Fefaidnbmnnnibpcajpcglclefindmkaj%2F_generated_background_page.html&v1=15.1.3.9&v2=sideload&v3=prod&v4=unknown&AQE=1", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_submit_data("register3", 
		"Action=https://{host_android_clients_google_com}/c2dm/register3", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.chrome.windows", ENDITEM, 
		"Name=X-subtype", "Value=com.google.chrome.fcm.invalidations-1013309121859", ENDITEM, 
		"Name=device", "Value=5062287027606988380", ENDITEM, 
		"Name=scope", "Value=GCM", ENDITEM, 
		"Name=X-scope", "Value=GCM", ENDITEM, 
		"Name=gmsv", "Value=99", ENDITEM, 
		"Name=appid", "Value=c1iD9cOtN4M", ENDITEM, 
		"Name=sender", "Value=1013309121859", ENDITEM, 
		LAST);

	web_submit_data("register3_2", 
		"Action=https://{host_android_clients_google_com}/c2dm/register3", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.chrome.windows", ENDITEM, 
		"Name=X-subtype", "Value=com.google.chrome.fcm.invalidations", ENDITEM, 
		"Name=device", "Value=5062287027606988380", ENDITEM, 
		"Name=scope", "Value=GCM", ENDITEM, 
		"Name=X-scope", "Value=GCM", ENDITEM, 
		"Name=gmsv", "Value=99", ENDITEM, 
		"Name=appid", "Value=cHr8z213RbQ", ENDITEM, 
		"Name=sender", "Value=8181035976", ENDITEM, 
		"Name=ttl", "Value=1209600", ENDITEM, 
		LAST);

	lr_start_transaction("01_Start");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,oimompecagnajdejgnnjijobebaeigek,hnimpnehoodheedghdeeijklkeaacbdc,gcmjkmgdlgnkkcocmoeiminaijmmjnii,cmahhnpholdijhjokonmfdjbfmklppij,obedbbhbpmojnkanicioggnmelmoomoc,giekcmmlnklenlaomppkphknjmnnpneh,khaoiebndkojlmppeemjhbpbandiljpe,llkgjffcdpffmhiakmfcdcblohccpfmo,kiabhabjdbkjdpjbpigfodbdjmbglcoo,laoigpblnllgcgjnjnllmfolckpjlhki,hfnkpimlhhgieaddgfemjhofmfblmnib,ehgidpndbllacpjalkiimkbadgjfnnmc,jflookgnkcckhobaglndicnbbgbonegd,lmelglejhemejginpboagddgdfbepgmp,"
		"gonpemdgkjcecdgbnaabipppbmgfggbe,ggkkehgbnfjpeggfpleeakpidbkibbmn,dhlpobdgcjafebgbbhjdnapejmpkgiie,efniojlnjndmcbiieegkicadnoecjjef,ojhpjlocmbogdgmfpkhlaaeamibhnphh,pdafiollngonhoadbmdoemagnfpdphbe,imefjhfbkmcmebodilednhmaccmincoa,gkmgaooipdjhmangpemjhigmamcehddo,jamhcnnkihinmdlkakkaopbjbbcngflc,eeigpngbgcognadeebkilcpcaedhellh");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-99.0.4844.51");

	lr_think_time(57);

	web_custom_request("json", 
		"URL=https://{host_update_googleapis_com}/service/update2/json?cup2key=11:RgIAPC44rCJn5vBDbrRthMjCazlr4mTtfmvk64fbuhs&cup2hreq=10944c1a43fc8d7f5d725c854b31ea686785ce277d28da6c3e3134f6cd1cd3e5", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEB\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{f0e53ff9-8e46-40ef-bbfd-14984a1eddf5}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEB\",\"cohort\":\"1::\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{ea44fefb-7f71-446b-8fce-e87ca2e2f146}\","
		"\"rd\":5551},\"updatecheck\":{},\"version\":\"4.10.2449.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEB\",\"cohort\":\"1::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{0a55631d-f372-4f84-adea-62750a71befe}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEB\",\"cohort\":\"1:bm1:\",\""
		"cohorthint\":\"M54AndUp\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.93823a4e71e764b932ee22dfcf84c24429867a440c5e480e55be527ac30de1ae\"}]},\"ping\":{\"ping_freshness\":\"{e8c63c24-8313-438f-91a9-c91ac099bbab}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"9.34.0\"},{\"appid\":\"cmahhnpholdijhjokonmfdjbfmklppij\",\"brand\":\"GCEB\",\"cohort\":\"1:wr3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.b4ddbdce4f8d5c080328aa34c19cb533f2eedec580b5d97dc14f74935e4756b7\"}]},\"ping\":{\"ping_freshness\":\"{9df03255-6247-4cba-a302-108d7a2d49b6}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"1.0.6\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GCEB\",\"cohort\":\"1:s6f:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.d57ce9f6021155c0d2849c5f9ad519fb14fe66a6bfad04d03554c1a4f4f57487\"}]},\"ping"
		"\":{\"ping_freshness\":\"{905db38f-660d-42de-8c46-9f9eddad286b}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"20220221.430924452\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEB\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{cd62eb7e-194b-4671-b013-9d5678cd6b16}\",\"rd\":5551},\"updatecheck\":{},"
		"\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEB\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5f1c8af8a15da419e629cc50d85e7326cda080bd1f7df8ac38a16b98e0a2739b\"}]},\"ping\":{\"ping_freshness\":\"{82bac6ba-1d37-464f-b784-080ee6e80ab5}\",\"rd\":5551},\"tag\":\"46\",\"updatecheck\":{},\"version\":\"48\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEB\",\"cohort\":\"1"
		"::\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.cce0f625048d9fed1478ce771b0ba5d7526d26f9c92a3a539d2885a9fc1fa1d6\"}]},\"ping\":{\"ping_freshness\":\"{8fb2a15d-6914-4222-b624-06d6049e0bf2}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"1.0.0.12\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GCEB\",\"cohort\":\"1:v3l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.b5bacf71d8233b978e24a19b53b2f723cedcc279abbe69fd164b8f916f4f8538\"}]},\"ping\":{\"ping_freshness\":\"{f4912c52-97a8-4e2b-af66-74a0876c9eec}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2022.3.12.4\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GCEB\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.db60fc5d4ab81e28fe58d82f3ad26622c4ca4cade28e2b636068ac91ca62224d\"}]},\"ping\":{\"ping_freshness\":\""
		"{71a31371-4004-49b6-ba4b-e8dfd4e2d455}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"1.0.7.1642025427\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEB\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.e035285fcd892be9376dd70ae7226d3dc4964e91798a6693fa3455cf0f7212bd\"}]},\"ping\":{\"ping_freshness\":\"{c9afd9c8-7ab9-4a92-9dfd-752d1fb07eda}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"7215\"},{\""
		"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEB\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{e46c2fd1-cb3a-4fe8-a26a-696a655150ba}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GCEB\",\"cohort\":\"1:s7x:\",\"cohorthint"
		"\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.28d42883451514ec6a6380a754b1257eb3e9f0c992cb4f0d2741a809e343e356\"}]},\"ping\":{\"ping_freshness\":\"{8d3651b3-d31b-4320-8fee-3481429dadf2}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2782\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GCEB\",\"cohort\":\"1:lwl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.a6292b06720de27ac2e8dd808ed5631ad974a6457677e8bf403289e526670fbd\"}]},\"ping\":{\"ping_freshness\":\"{4cb3a8c8-b0b4-44cd-bf06-c353e3b9345f}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"322\"},{\"_internal_experimental_sets\":\"false\",\"_v2_format_plz\":\"true\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GCEB\",\"cohort\":\"1:13c9:\",\"cohorthint\":\"V2 General release\",\"cohortname\":\"V2 General release\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.c51d23bc0653142853b0d9dc8ba00f504aaae8a2a5b290e539b8790d88c0dcbe\"}]},\"ping\":{\"ping_freshness\":\"{c6d054bd-afcd-4660-a85c-12cf6e6ad5df}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2022.2.15.1\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GCEB\",\"cohort\":\"1:ut9:13u9@0.01\",\"cohorthint\":\"M80AndAbove\",\"cohortname\":\"M80AndAbove\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.7fb66dac0cfeaf15642abf45b4451a728347d6f8dea21a26c66df47c12beda8f\"}]},\"ping\":{"
		"\"ping_freshness\":\"{af341873-2fb3-4457-829f-45131ccdf44d}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2022.2.28.1201\"},{\"appid\":\"dhlpobdgcjafebgbbhjdnapejmpkgiie\",\"brand\":\"GCEB\",\"cohort\":\"1:z9x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.8b9dc2cd32d1b5f147a17377cef75ec160103d6c02faf4947978fb6d9a25983b\"}]},\"ping\":{\"ping_freshness\":\"{a029611f-91d9-4c07-8c2b-18919903a4d6}\",\"rd\":5551},\"updatecheck\":{},\""
		"version\":\"20211020.1\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GCEB\",\"cohort\":\"1:zkl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3d3aba54794191131486b006fbf81fb8618068ecb5d5962dae11c95dbd9902bc\"}]},\"ping\":{\"ping_freshness\":\"{31ea0a67-78f0-444a-a34f-90bc7708f20c}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"202\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GCEB\",\"cohort\":\"1:w0x:\""
		",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.478aa915e78878e332a0b4bb4d2a6fb67ff1c7f7b62fe906f47095ba5ae112d0\"}]},\"ping\":{\"ping_freshness\":\"{e2e61e09-f7d6-4446-bb15-bcf1f13bd336}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"1\"},{\"appid\":\"pdafiollngonhoadbmdoemagnfpdphbe\",\"brand\":\"GCEB\",\"cohort\":\"1:vz3:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.54b93e249d02a0f9061e8f70866d4668a0260db9ae43483810ab78f97f3eaa2a\"}]},\"ping\":{\"ping_freshness\":\"{0c049bd9-ef44-4daf-9bf4-05650f73ac05}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2021.8.17.1300\"},{\"appid\":\"imefjhfbkmcmebodilednhmaccmincoa\",\"brand\":\"GCEB\",\"cohort\":\"1:zor:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.90d6e329a99396aced52c13595b29a8af1e2711cdd6f73008ae51d0be83356be\"}]},\"ping\":{\"ping_freshness\":\""
		"{d942a899-0060-43eb-aa46-48b77574ccc5}\",\"rd\":5551},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"27.5\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GCEB\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.f34e17cc90ce3e33fece88503070bc71be525c6a75d5a516addf758ae811eb5f\"}]},\"ping\":{\"ping_freshness\":\"{bacfd721-39e7-4718-84ee-15870a824c10}\",\"rd\":5551},\"tag\":\"eset_exp_b\",\""
		"updatecheck\":{},\"version\":\"99.279.200\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GCEB\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ce3b4e3541a765f4e50c22c06f27bf0728878efd196309df069d5b39bffccd1d\"}]},\"ping\":{\"ping_freshness\":\"{428d42a2-66ca-401b-852c-b01015f98ec7}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"101.0.4944.0\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\""
		"GCEB\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{d63ca7e8-1a08-43d3-a7a9-e08166631adf}\",\"rd\":5551},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\""
		":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19042.1348\"},\"prodversion\":\"99.0.4844.51\",\"protocol\":\"3.1\",\"requestid\":\"{3c3527f2-6cb2-43ee-a4fa-99bbb60eaee9}\",\"sessionid\":\"{8ccb5305-327a-4623-bb6b-547745ae5172}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\""
		"1.3.36.122\"},\"updaterversion\":\"99.0.4844.51\"}}", 
		EXTRARES, 
		"Url=http://{host_edgedl_me_gvt1_com}/edgedl/delta-update/jflookgnkcckhobaglndicnbbgbonegd/1.6a0fd34aa25746f0521bf72c4175bfa20aa77842f477f685bb8789cdaced8e9f/1.28d42883451514ec6a6380a754b1257eb3e9f0c992cb4f0d2741a809e343e356/33a6bccfe60d1f92a47369f01ba72b65889f311beec7515c071b17fcbf94824c.crxd", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("json_2", 
		"URL=https://{host_update_googleapis_com}/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GCEB\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"event\":[{\"download_time_ms\":13,\"downloader\":\"bits\",\"errorcode\":-2147024890,\"eventresult\":0,\"eventtype\":14,\"nextversion\":\"2783\",\"previousversion\":\"2782\",\"url\":\"http://{host_edgedl_me_gvt1_com}/edgedl/delta-update/"
		"jflookgnkcckhobaglndicnbbgbonegd/1.6a0fd34aa25746f0521bf72c4175bfa20aa77842f477f685bb8789cdaced8e9f/1.28d42883451514ec6a6380a754b1257eb3e9f0c992cb4f0d2741a809e343e356/33a6bccfe60d1f92a47369f01ba72b65889f311beec7515c071b17fcbf94824c.crxd\"},{\"download_time_ms\":939,\"downloaded\":3849,\"downloader\":\"direct\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"2783\",\"previousversion\":\"2782\",\"total\":3849,\"url\":\"http://{host_edgedl_me_gvt1_com}/edgedl/delta-update/"
		"jflookgnkcckhobaglndicnbbgbonegd/1.6a0fd34aa25746f0521bf72c4175bfa20aa77842f477f685bb8789cdaced8e9f/1.28d42883451514ec6a6380a754b1257eb3e9f0c992cb4f0d2741a809e343e356/33a6bccfe60d1f92a47369f01ba72b65889f311beec7515c071b17fcbf94824c.crxd\"},{\"diffresult\":1,\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.6a0fd34aa25746f0521bf72c4175bfa20aa77842f477f685bb8789cdaced8e9f\",\"nextversion\":\"2783\",\"previousfp\":\"1.28d42883451514ec6a6380a754b1257eb3e9f0c992cb4f0d2741a809e343e356\",\""
		"previousversion\":\"2782\"}],\"packages\":{\"package\":[{\"fp\":\"1.6a0fd34aa25746f0521bf72c4175bfa20aa77842f477f685bb8789cdaced8e9f\"}]},\"version\":\"2783\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"en-GB\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.19042.1348\"},\""
		"prodversion\":\"99.0.4844.51\",\"protocol\":\"3.1\",\"requestid\":\"{6874b994-0aba-4311-8cf8-1e1deaee51e6}\",\"sessionid\":\"{8ccb5305-327a-4623-bb6b-547745ae5172}\",\"updaterversion\":\"99.0.4844.51\"}}", 
		LAST);

	web_add_auto_header("Origin", 
		"https://{host_challenge_flood_io}");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Google Chrome\";v=\"99\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_submit_data("start", 
		"Action=https://{host_challenge_flood_io}/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host_challenge_flood_io}/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=utf8", "Value=✓", ENDITEM, 
		"Name=authenticity_token", "Value=UiIpJXtNvKpsEpPGwu1Ihduoa2y2mGGMqm0qtuMvr5c=", ENDITEM, 
		"Name=challenger[step_id]", "Value=N1V6OWh3Q2M1OWFKNFBVbWtKa0JaZz09LS1FWlRUNU5mNUdCRWhQK1dmZG1PZXpRPT0=--a5c27f0b39465df471b9ad66fe92a867837dcebb", ENDITEM, 
		"Name=challenger[step_number]", "Value=1", ENDITEM, 
		"Name=commit", "Value=Start", ENDITEM, 
		LAST);

	lr_end_transaction("01_Start",LR_AUTO);

	lr_start_transaction("02_SelectAge");

	web_submit_data("start_2", 
		"Action=https://{host_challenge_flood_io}/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host_challenge_flood_io}/step/2", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=utf8", "Value=✓", ENDITEM, 
		"Name=authenticity_token", "Value=UiIpJXtNvKpsEpPGwu1Ihduoa2y2mGGMqm0qtuMvr5c=", ENDITEM, 
		"Name=challenger[step_id]", "Value=QVZjbWxVbkwzY0dnY1prOHVTdXN4UT09LS0vYjJkQ0ZRaVFBMnp1Ui9qYy9mb0NnPT0=--920bc0cd3ee357709e23af3945bed7c105d5e815", ENDITEM, 
		"Name=challenger[step_number]", "Value=2", ENDITEM, 
		"Name=challenger[age]", "Value=44", ENDITEM, 
		"Name=commit", "Value=Next", ENDITEM, 
		LAST);

	lr_end_transaction("02_SelectAge",LR_AUTO);

	lr_start_transaction("03_SelectOrder");

	web_submit_data("start_3", 
		"Action=https://{host_challenge_flood_io}/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host_challenge_flood_io}/step/3", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=utf8", "Value=✓", ENDITEM, 
		"Name=authenticity_token", "Value=UiIpJXtNvKpsEpPGwu1Ihduoa2y2mGGMqm0qtuMvr5c=", ENDITEM, 
		"Name=challenger[step_id]", "Value=ZSs3R3plVWZyVXY0TGUrUVY1a29tQT09LS1GL3ExUWswWE9FTkhpOGRlMURxZS9nPT0=--c70f1b98d1f2f498aeb81a538bf17f930b07942f", ENDITEM, 
		"Name=challenger[step_number]", "Value=3", ENDITEM, 
		"Name=challenger[largest_order]", "Value=227", ENDITEM, 
		"Name=challenger[order_selected]", "Value=Nm42L1BOSS9Kd1RUc2g1a0QzdUtXZz09LS1OalRuVzljVmNBNy9xL3l5TVMwVktBPT0=--34242adb37d007a385ffb6b2dd7ad172c371449c", ENDITEM, 
		"Name=commit", "Value=Next", ENDITEM, 
		LAST);

	lr_end_transaction("03_SelectOrder",LR_AUTO);

	lr_start_transaction("04_ClickNext");

	web_submit_data("start_4", 
		"Action=https://{host_challenge_flood_io}/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host_challenge_flood_io}/step/4", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=utf8", "Value=✓", ENDITEM, 
		"Name=authenticity_token", "Value=UiIpJXtNvKpsEpPGwu1Ihduoa2y2mGGMqm0qtuMvr5c=", ENDITEM, 
		"Name=challenger[step_id]", "Value=T3B6VmtnS1Vid1NrRlo0ODdsSGZBQT09LS1Vbkp1VmYvZHhOK0M5NWZlOUNwNjhBPT0=--ea813e3df5b55b95b2281c865f731b15f62a3da2", ENDITEM, 
		"Name=challenger[step_number]", "Value=4", ENDITEM, 
		"Name=challenger[order_4]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_1]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_7]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_3]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_9]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_8]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_10]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_10]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_13]", "Value=1647298378", ENDITEM, 
		"Name=challenger[order_17]", "Value=1647298378", ENDITEM, 
		"Name=commit", "Value=Next", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("code", 
		"URL=https://{host_challenge_flood_io}/code", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{host_challenge_flood_io}/step/5", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("04_ClickNext",LR_AUTO);

	lr_start_transaction("05_EnterToken");

	web_add_header("Origin", 
		"https://{host_challenge_flood_io}");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("start_5", 
		"Action=https://{host_challenge_flood_io}/start", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://{host_challenge_flood_io}/step/5", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=utf8", "Value=✓", ENDITEM, 
		"Name=authenticity_token", "Value=UiIpJXtNvKpsEpPGwu1Ihduoa2y2mGGMqm0qtuMvr5c=", ENDITEM, 
		"Name=challenger[step_id]", "Value=S2RzcTEwdlN1RW1ZNzlUemd0dFZtZz09LS1xVFAyLzVjT1QyVzRpTzNjRUFNZjBRPT0=--73bc7709267f614143cb14f6d990de54497ba919", ENDITEM, 
		"Name=challenger[step_number]", "Value=5", ENDITEM, 
		"Name=challenger[one_time_token]", "Value=2802469144", ENDITEM, 
		"Name=commit", "Value=Next", ENDITEM, 
		LAST);

	lr_end_transaction("05_EnterToken",LR_AUTO);

	return 0;
}